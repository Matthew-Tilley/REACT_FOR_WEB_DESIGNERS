(function() {
  "use strict";

  var ProductCustomizer = React.createElement(
    "div",
    { className: "customizer" },
    "Product customizer will go here"
  );

  ReactDOM.render(ProductCustomizer, document.getElementById("react-root"));
})();
