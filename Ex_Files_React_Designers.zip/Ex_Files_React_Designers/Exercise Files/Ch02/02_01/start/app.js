(function() {
  "use strict";

  // Start here

})();
